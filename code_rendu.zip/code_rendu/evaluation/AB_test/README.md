# A/B Test

Just a try... it's not working !

     # Start the python server (flask) and firefox
     ./ab_app.sh

     # You may need to refresh the page after a few seconds...
