# Wrapper : Reddit's links

Bring back link names, and create a csv that associate each link to its posts (i.e. the comments which have parent_id=link_id)

## Usage

	# Make everything
	make
	
	# Just download JSONs
	make download

