# Machine learning

## Usage

    # Train ML model
    python3 main.py

Need keras libraries to work.

## Scripts

 - cleantext.py: remove url, emojis, etc. from texts
 - data_gen.py: comment threads generator, using Cypher or SLite
 - embeddings.py: comment-embeddings using Glove
 - evaluation.py: empty module
 - exploration.py: data exploration / analysis
 - main.py: main program
 - model.py: ML model with attention layers
 - preprocessing.py: preprocessing of standard features
 - train.py: training module

